-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 27, 2021 at 06:46 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `castle`
--

-- --------------------------------------------------------

--
-- Table structure for table `tabel_admin`
--

CREATE TABLE `tabel_admin` (
  `idAdmin` varchar(11) NOT NULL,
  `namaAdmin` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tabel_admin`
--

INSERT INTO `tabel_admin` (`idAdmin`, `namaAdmin`, `email`, `password`) VALUES
('1', 'admin', 'admin@admin.com', '21232f297a57a5a743894a0e4a801fc3'),
('2', 'hernan', 'hernan@hernan.com', '9e1e06ec8e02f0a0074f2fcc6b26303b'),
('3', 'aziz', 'aziz@aziz.com', '202cb962ac59075b964b07152d234b70');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_kategori`
--

CREATE TABLE `tabel_kategori` (
  `idKategori` int(11) NOT NULL,
  `namaKategori` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tabel_kategori`
--

INSERT INTO `tabel_kategori` (`idKategori`, `namaKategori`) VALUES
(1, 'Pria'),
(2, 'Wanita'),
(3, 'Anak-anak'),
(4, 'Couple'),
(5, 'Sarimbit');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_keranjang`
--

CREATE TABLE `tabel_keranjang` (
  `idKeranjang` varchar(11) NOT NULL,
  `idUser` int(11) NOT NULL,
  `idProduk` varchar(11) NOT NULL,
  `namaProduk` varchar(100) NOT NULL,
  `harga` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tabel_komentar`
--

CREATE TABLE `tabel_komentar` (
  `idKomen` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pesan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tabel_komentar`
--

INSERT INTO `tabel_komentar` (`idKomen`, `nama`, `email`, `pesan`) VALUES
(1, 'bayu', 'bayu@bayu.com', 'bagus'),
(2, 'azis', 'azis@gmail.com', 'min produknya sangat bagus dan terpecaya harga nya terjangkau adminnnya fast respon');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_produk`
--

CREATE TABLE `tabel_produk` (
  `idProduk` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `gambar` text NOT NULL,
  `ukuran` varchar(100) NOT NULL,
  `keterangan` text NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `harga` int(11) NOT NULL,
  `stock` int(11) NOT NULL,
  `path` varchar(50) NOT NULL,
  `size` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tabel_produk`
--

INSERT INTO `tabel_produk` (`idProduk`, `nama`, `gambar`, `ukuran`, `keterangan`, `kategori`, `harga`, `stock`, `path`, `size`) VALUES
(21, 'Kaos burung elang', 'p1', 'L', 'Lengan pendek\r\nBahan cotton\r\ndesain yang cantik', 'pria', 70000, 19, 'image/p1.jpeg', 101728),
(22, 'Kaos panjang raden pria', 'p18', 'L', 'Bahan kualitas premium', 'pria', 65000, 16, 'image/p18.jpeg', 48168),
(23, 'Kaos Batik bali Pendek', 'p6', 'M', 'Kaos Batik bali Pendek M', 'pria', 80000, 11, 'image/p6.jpeg', 77418),
(24, 'Kaos Lengan Pendek petong Premium', 'p8', 'L', 'Kualitas Premium', 'pria', 100000, 31, 'image/p8.jpeg', 46758),
(25, 'Kaos kartini', 'p5', 'L', 'Bahan nya enak dingin dari bahan tenun', 'wanita', 85000, 11, 'image/p5.jpeg', 138829),
(26, 'Kaos lengan panjang kupu-kupu', 'p9', 'L', 'warna yang cerah ', 'wanita', 87000, 20, 'image/p9.jpeg', 401299),
(27, 'Kaos lengan panjang bunga', 'p16', 'M', 'Kaos bunga yang sangat cantik', 'wanita', 95000, 10, 'image/p16.jpeg', 116487),
(28, 'Kaos lengan panjang motif ratu', 'p17', 'L', 'bahan terbuat dari kain katun', 'wanita', 100000, 12, 'image/p17.jpeg', 82566),
(29, 'Kaos couple ', 'p15', 'L', 'bagus untuk pasangan anda ', 'couple', 165000, 11, 'image/p15.jpeg', 96000),
(30, 'kaos Anak stasiun jogja', 'p2', 's', 'kaos yang begitu elegan', 'anak', 78000, 7, 'image/p2.jpeg', 134794),
(31, 'Kaos anak anoman', 'p10', 'S', 'kaos Anak Pria', 'anak', 90000, 13, 'image/p10.jpeg', 312814),
(32, 'keluarga', 'p14', 'L', 'cocok untuk keluarga', 'sarimbit', 380000, 12, 'image/p14.jpeg', 86826),
(33, 'Kaos raden', '41ab96e8c54ea88dd702cbde3093a975', 'L', 'kaos perempuan motif raden lengan panjang', 'wanita', 86000, 12, 'image/41ab96e8c54ea88dd702cbde3093a975.png', 242889),
(34, 'Kaos raden', '3052fa9be70689831345d203256be5ee', 'M', 'kaos raden lengan panjang', 'pria', 78000, 21, 'image/3052fa9be70689831345d203256be5ee.png', 242889),
(35, 'kaos oblong', '655efdd8c4a0a74544036d1376c01cfb', 'S', 'ready stok', 'anak', 100000, 12, 'image/655efdd8c4a0a74544036d1376c01cfb.png', 98526);

-- --------------------------------------------------------

--
-- Table structure for table `tabel_transaksi`
--

CREATE TABLE `tabel_transaksi` (
  `idTransaksi` int(11) NOT NULL,
  `idUser` varchar(11) NOT NULL,
  `daftarBarang` text NOT NULL,
  `tanggal` date NOT NULL,
  `total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tabel_transaksi`
--

INSERT INTO `tabel_transaksi` (`idTransaksi`, `idUser`, `daftarBarang`, `tanggal`, `total`) VALUES
(8, '6', 'Kaos burung elang, Kategori : pria, Jumlah : 1<br>Kaos panjang raden pria, Kategori : pria, Jumlah : 1<br>', '2021-01-25', 135000),
(9, '6', 'Kaos panjang raden pria, Kategori : pria, Jumlah : 1<br>', '2021-01-25', 65000),
(10, '6', 'Kaos panjang raden pria, Kategori : pria, Jumlah : 1<br>', '2021-01-25', 65000),
(11, '6', 'Kaos Batik bali Pendek, Kategori : pria, Jumlah : 1<br>', '2021-01-25', 80000),
(12, '6', 'Kaos burung elang, Kategori : pria, Jumlah : 1<br>Kaos couple , Kategori : couple, Jumlah : 1<br>', '2021-01-25', 235000),
(13, '6', 'kaos Anak stasiun jogja, Kategori : anak, Jumlah : 1<br>Kaos kartini, Kategori : wanita, Jumlah : 1<br>Kaos panjang raden pria, Kategori : pria, Jumlah : 1<br>', '2021-01-26', 228000);

-- --------------------------------------------------------

--
-- Table structure for table `tabel_trolly`
--

CREATE TABLE `tabel_trolly` (
  `idTrolly` int(11) NOT NULL,
  `idUser` int(11) NOT NULL,
  `idProduk` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tabel_trolly`
--

INSERT INTO `tabel_trolly` (`idTrolly`, `idUser`, `idProduk`, `jumlah`, `harga`) VALUES
(1, 4, 28, 1, 205000),
(16, 6, 21, 1, 70000),
(17, 6, 21, 1, 70000);

-- --------------------------------------------------------

--
-- Table structure for table `tabel_user`
--

CREATE TABLE `tabel_user` (
  `idUser` int(11) NOT NULL,
  `namaUser` varchar(50) NOT NULL,
  `email` varchar(70) NOT NULL,
  `password` varchar(40) NOT NULL,
  `alamat` text NOT NULL,
  `telpon` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tabel_user`
--

INSERT INTO `tabel_user` (`idUser`, `namaUser`, `email`, `password`, `alamat`, `telpon`) VALUES
(5, 'user', 'user@user.com', 'ee11cbb19052e40b07aac0ca060c23ee', 'Malang', '0897666555'),
(6, 'bayu', 'bayu@bayu.com', '827ccb0eea8a706c4c34a16891f84e7b', 'klaten', '0989776776');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tabel_admin`
--
ALTER TABLE `tabel_admin`
  ADD PRIMARY KEY (`idAdmin`);

--
-- Indexes for table `tabel_kategori`
--
ALTER TABLE `tabel_kategori`
  ADD PRIMARY KEY (`idKategori`);

--
-- Indexes for table `tabel_keranjang`
--
ALTER TABLE `tabel_keranjang`
  ADD PRIMARY KEY (`idKeranjang`);

--
-- Indexes for table `tabel_komentar`
--
ALTER TABLE `tabel_komentar`
  ADD PRIMARY KEY (`idKomen`);

--
-- Indexes for table `tabel_produk`
--
ALTER TABLE `tabel_produk`
  ADD PRIMARY KEY (`idProduk`);

--
-- Indexes for table `tabel_transaksi`
--
ALTER TABLE `tabel_transaksi`
  ADD PRIMARY KEY (`idTransaksi`);

--
-- Indexes for table `tabel_trolly`
--
ALTER TABLE `tabel_trolly`
  ADD PRIMARY KEY (`idTrolly`);

--
-- Indexes for table `tabel_user`
--
ALTER TABLE `tabel_user`
  ADD PRIMARY KEY (`idUser`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tabel_komentar`
--
ALTER TABLE `tabel_komentar`
  MODIFY `idKomen` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tabel_produk`
--
ALTER TABLE `tabel_produk`
  MODIFY `idProduk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `tabel_transaksi`
--
ALTER TABLE `tabel_transaksi`
  MODIFY `idTransaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tabel_trolly`
--
ALTER TABLE `tabel_trolly`
  MODIFY `idTrolly` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tabel_user`
--
ALTER TABLE `tabel_user`
  MODIFY `idUser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
