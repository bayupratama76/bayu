<!-- footer -->
  <div class="container-fluid" id="footer">
    <div class="row">
      <div class="col-xs-3 text-white">
        <img src="asset/img/Title tengah.png">
        <p style="padding-left: 1.3vw;margin-top: 8px; font-family: Eras Demi ITC; font-size: 17px">
        Castle Art Clothing adalah sebuah website sederhana yang memasarkan produk seni dimana penjualan utama nya berfokus pada kaos lukis. Kami menawarkan sebuah produk yang exclusive dan arsty, karena kami melakukan proses made by order. Jadi kita tidak meninggalkan ke suatu khas dari seni itu sendiri yang prosesnya membutuhkan waktu yang sedikit lama dibandingkan industri lain. Diwebsite ini kami juga menggunakan sistem ready stock yang sudah berada di beranda katalog dari kami yang bisa langsung di order oleh pengguna.Karena kami menawarkan produk seni, kita akan memproses pesanan (pre-order) setelah konsumen melakukan transaksi via transfer. website ini beroperasi selama 24 jam dan setiap bulan produk yang kami tawarkan seperti baju, jaket serta hoodie,akan selalu berganti dengan versi terbaru.Terimakasih telah mengunjungi Website kami</p>
       
      </div>
      
      <div class="col-xs-3 col-xs-offset-1 text-white">
        <h3 style="font-family:Cooper Std Black">Hubungi Kami</h3>
        <hr>
        <a href=target="_blank"><img style="width: 40px; height: 40px; margin-right: 1vw;" src="asset/img/facebook.png"></a>
        <a href="https://www.youtube.com" target="_blank"><img style="width: 40px; height: 40px; margin-right: 1vw;" src="asset/img/youtube.png"></a>
        <a href="https://www.instagram.com/castlekaoslukis" target="_blank"><img style="width: 40px; height: 40px; margin-right: 1vw;" src="asset/img/instagram.png"></a>
        <h5 style="margin-top: 7vh; font-family: News706 BT; font-size: 15px">Kantor Pusat :</h5>
        <div id="map" style="width:20vw;height:30vh;background:black; border-radius:5px"></div>
        
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d31622.51518962966!2d110.34055743955076!3d-7.809463099999997!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e7a5793ab6bf6e5%3A0x5a086b2047dda9c5!2sWater%20Castle%20Art%20Shop!5e0!3m2!1sid!2sid!4v1611549505256!5m2!1sid!2sid" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
      </div>
      
      <div class="col-xs-3 col-xs-offset-1 text-white">
      <h3 style="font-family:Cooper Std Black">Komentar Pelanggan </h3>
      <hr>
      <br>
        <form action="./proses/komentar.php" method="post" role="form">
          <div class="form-group">
            <label for="nama">Nama : </label>
            <input type="text" class="form-control" name="nama" placeholder="Nama">
          </div>
          <div class="form-group">
            <label for="email">Email : </label>
            <input type="text" class="form-control" name="email" placeholder="Email">
          </div>
          <div class="form-group">
            <label for="pesan">Pesan : </label>
            <textarea class="form-control" name="pesan" placeholder="Masukkan pesan "></textarea>
          </div>
          <button type="submit" class="btn btn-primary">Kirim</button>
        </form>
      </div>

    </div>
    <div class="row" id="cpy">
      <div class="col-xs-12">
        <p style="color : white; text-align: center;">&copy; Castle Art Clothing</p>
      </div>
    </div>
  </div>
<!-- end of footer -->